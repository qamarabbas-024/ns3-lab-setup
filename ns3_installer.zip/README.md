# ns-3 Automated One-Click Setup for Windows 10 & 11

[![Windows 10 & 11 Compatible](https://img.shields.io/badge/Windows-10%20%7C%2011%20(64--bit)-blue?logo=windows&logoColor=white)](https://microsoft.com)
[![WSL2 Ubuntu](https://img.shields.io/badge/WSL2-Ubuntu%20Linux-E95420?logo=ubuntu&logoColor=white)](https://ubuntu.com)
[![ns-3 Simulator](https://img.shields.io/badge/ns--3-Network%20Simulator%203-00599C?logo=c%2B%2B&logoColor=white)](https://www.nsnam.org)
[![VS Code Remote](https://img.shields.io/badge/VS%20Code-WSL%20Integrated-007ACC?logo=visualstudiocode&logoColor=white)](https://code.visualstudio.com)
[![Author](https://img.shields.io/badge/Author-Qamar%20Abbas-blue)](https://github.com/qamarabbas-024)

> **Prepared with care for Students**  
> *Facilitated and engineered by Qamar Abbas*

An autonomous, 100% self-contained one-click installer (`INSTALL_ALL_ns3.bat`) that prepares, configures, compiles, and verifies the complete **ns-3 Network Simulation Environment** on Windows 10 and Windows 11 machines.

---

## 🎯 The Problems This Tool Solves for Students

Setting up ns-3 on Windows has historically been one of the most frustrating hurdles for computer science students. In a typical class of 50+ students, 70–80% run into blocking technical errors. This tool eliminates all of them:

| # | Common Student Problem | Why It Happened | How This Installer Fixes It |
|---|---|---|---|
| **1** | **Terminal Vanished on Launch** | Older scripts used raw batch files or multi-line strings in generated wrappers that crashed Windows `cmd.exe` on startup. Double-clicking caused the terminal window to disappear instantly. | Re-engineered with native Windows `echo` wrappers, robust launch hooks, and `exec bash` fallback guards so the terminal never crashes or vanishes. |
| **2** | **`WSL_E_DISTRO_NOT_FOUND`** | Newer Windows 10/11 updates register distros under versioned names like `Ubuntu-24.04` or `Ubuntu-22.04`. Hardcoded calls to `wsl -d Ubuntu` fail with distro not found. | **Dynamic Distro Discovery Engine** scans installed distributions live (`Get-TargetWSLDistro`) and binds dynamically to whatever Ubuntu/Debian flavor is present. |
| **3** | **C: Drive Full / Out of Disk Space** | Many students only have 5–10 GB free on `C:`, but have 200+ GB available on secondary drives (`D:`, `E:`, etc.). Previous scripts refused to install or crashed. | **Multi-Drive Partition Selector:** Scans all drives, displays an interactive storage table, recommends the best drive, and relocates WSL virtual disks (`.vhdx`) to the chosen drive using native `wsl --manage --move`. |
| **4** | **Windows 11 "Smart App Control" Block** | Downloaded files from WhatsApp/Drive attach the NTFS `Zone.Identifier` ("Mark of the Web"), causing Windows 11 SAC to block execution with no "Run anyway" button. | Built-in **Self-Unblocking** via PowerShell `Unblock-File` and clear 10-second student instructions for systems with strict pre-launch policies. |
| **5** | **Windows 10 vs. Windows 11 Differences** | Modern `wsl --install` is missing or unrecognized on older Windows 10 builds (`< 19041`). | Automatically audits the Windows build number and falls back to native Windows DISM feature enablement (`Microsoft-Windows-Subsystem-Linux` and `VirtualMachinePlatform`). |
| **6** | **BIOS Virtualization (VT-x / AMD-V) Disabled** | Budget laptops (HP, Dell, Lenovo, Asus, Acer) often ship with hardware virtualization disabled in BIOS, causing WSL2 to fail with error `0x80370102`. | Runs a **Pre-Flight Hardware Check** *before* doing anything, immediately detecting if virtualization is off and providing brand-specific BIOS key instructions. |
| **7** | **Laptop Freezing / Out-of-Memory (OOM)** | Standard `./ns3 build` compiles 4,000+ objects across all CPU cores. On laptops with 4–8 GB RAM, `g++` consumes all memory, thrashing the disk and freezing the system. | **Auto-tunes compilation concurrency** based on detected RAM: throttles to `-j 2` on 4GB systems and `-j 4` on 8GB systems to prevent overheating and freezing. |
| **8** | **Laptop Falling Asleep Mid-Compilation** | Compiling C++ takes 10–15 minutes. Windows battery profiles put laptops to sleep after 5 minutes of no keyboard touch, terminating the build. | Uses Windows API (`SetThreadExecutionState`) to **temporarily prevent sleep** while compiling, restoring normal power saving when finished. |
| **9** | **Uninitialized Ubuntu & Sudo Deadlocks** | Fresh WSL distros have no default user and prompt for passwords during non-interactive script runs, hanging indefinitely. | Directly provisions packages via `wsl -u root` and offers an automatic default password (`12345`) with passwordless sudo for lab exercises. |
| **10** | **Missing Visual Studio Code** | Many students do not have VS Code or installed it without checking "Add to PATH", causing `code .` to fail. | **Automatically downloads and installs official VS Code silently** from Microsoft CDN, configures PATH, and installs the Remote WSL extension. |
| **11** | **Massive Download Sizes & Stalling** | Full Git history of `ns-3-dev` is ~2 GB and stalls on slow home/campus Wi-Fi. | Uses a **shallow clone (`--depth 1`)**, reducing download size to only ~50 MB and finishing in ~1 minute. |
| **12** | **Duplicate Desktop Icons** | Writing shortcuts to both User and Public Desktop created 4 redundant icons on screen. | Scans and cleans Public Desktop duplicates and ensures exactly **2 clean 1-click shortcuts** on the user's desktop. |

---

## 🚀 Key Features

- **Single-File Standalone Architecture:** You only need to share or download one file: `INSTALL_ALL_ns3.bat`. Zero external `.sh` or `.py` files required.
- **Pre-Flight System Readiness Audit:** Inspects OS, 64-bit architecture, BIOS virtualization, RAM, free disk space (>= 15 GB), and internet connectivity before touching the system.
- **Real-Time Visual Feedback:** Ninja compilation counters and live download progress ensure students always see activity on screen.
- **Auto-Generated Desktop Shortcuts:** Automatically creates clean 1-click desktop shortcuts:
  - 🖥️ **`ns-3 Linux Terminal`**
  - 💻 **`ns-3 VS Code`**
- **Built-in Control Center:** Once installed, re-running `INSTALL_ALL_ns3.bat` opens an interactive management menu (launch terminal, open VS Code, run Lab 1 simulations, recompile, or repair).

---

## 📋 Installation Workflow

```mermaid
graph TD
    A[Download INSTALL_ALL_ns3.bat] --> B[Double-click & Accept UAC Elevation]
    B --> C[Phase 1: Pre-Flight System Readiness Audit]
    C --> D{Hardware & OS Pass?}
    D -- No (e.g. BIOS VT Off) --> E[Display Clear BIOS Fix Steps & Safe Pause]
    D -- Yes --> F[Phase 2: Storage Confirmation]
    F --> G[Phase 3: WSL2 & Ubuntu Provisioning]
    G --> H[Phase 4: User & Password Setup: 12345 or Custom]
    H --> I[Phase 5: Auto-Install VS Code & WSL Extension]
    I --> J[Phase 6: Install C++ Compilers & Build Tools]
    J --> K[Phase 7: Fast Shallow ns-3 Fetch & RAM-Tuned Build]
    K --> L[Phase 8: Automated Verification Tests]
    L --> M[Phase 9: Create Desktop Shortcuts]
    M --> N[Phase 10: Final Checklist & Launch Terminal]
```

---

## 💻 Quick Start Guide for Students

You can install ns-3 using either of the two methods below:

### 🚀 Option A: Instant 1-Click Command (Recommended — Zero-SAC Block)
This method streams the installer directly into memory without saving browser download tags (`Zone.Identifier`), completely bypassing Windows 11 **Smart App Control (SAC)** and SmartScreen warnings:

1. Press <kbd>Win</kbd> + <kbd>R</kbd> on your keyboard (opens the Windows Run box).
2. Copy and paste this command, then press **Enter**:
   ```powershell
   powershell -ep bypass -c "irm https://raw.githubusercontent.com/qamarabbas-024/ns3-lab-setup/main/INSTALL_ALL_ns3.bat | iex"
   ```
3. Click **"YES"** on the Administrator (UAC) prompt when it appears.
4. Sit back and watch the installer automatically configure everything!

---

### 📥 Option B: Download the `.bat` File Manually
If you received `INSTALL_ALL_ns3.bat` over WhatsApp or downloaded it manually:

1. Save `INSTALL_ALL_ns3.bat` to any folder on your laptop (e.g. `Downloads` or `Desktop`).
2. **If blocked by Windows 11 Smart App Control or SmartScreen:**
   - **Right-click** `INSTALL_ALL_ns3.bat` ➔ Click **Properties**.
   - At the bottom of the **General** tab, check the **"Unblock"** checkbox.
   - Click **Apply**, then **OK**.
3. **Double-click** `INSTALL_ALL_ns3.bat` and click **"YES"** on the Administrator prompt.

---

## 🧪 Included Verification Simulations

The installer automatically verifies the setup using the official ns-3 tutorial test suite:

### 1. Smoke Test (`hello-simulator`)
```bash
./ns3 run hello-simulator
```
**Expected Output:**
```text
Hello Simulator
```

### 2. Lab 1 Tutorial Test (`first.cc`)
Simulates a two-node point-to-point network transmitting 1024-byte packets:
```bash
./ns3 run first
```
**Expected Output:**
```text
At time +2s client sent 1024 bytes to 10.1.1.2 port 9
At time +2.00369s server received 1024 bytes from 10.1.1.1 port 49153
At time +2.00369s server sent 1024 bytes to 10.1.1.1 port 49153
At time +2.00737s client received 1024 bytes from 10.1.1.2 port 9
```

### 3. Lab 1 Multi-Node Routed Simulation (`lab1-simulation.cc`)
Simulates a 3-node routed topology (`[Client] <--> [Router] <--> [Server]`) across two subnets (`10.1.1.0/24` and `10.1.2.0/24`) with live packet tracing, RTT calculation (~24.1 ms), and automatic Wireshark `.pcap` capture:
```bash
./ns3 run lab1-simulation
```
**Expected Output:**
```text
======================================================================
               ns-3 NETWORK SIMULATION - LAB DEMO                     
                     Created by Qamar Abbas                           
======================================================================
[*] Initializing Network Topology:
    [Node 0: Client] <--- Link 1 (5 Mbps, 2ms) ---> [Node 1: Router]
    [Node 1: Router] <--- Link 2 (1.5 Mbps, 10ms) -> [Node 2: Server]

[*] IP Address Configuration:
    - Node 0 (Client) IP : 10.1.1.1
    - Node 1 (Router) IP1: 10.1.1.2
    - Node 1 (Router) IP2: 10.1.2.1
    - Node 2 (Server) IP : 10.1.2.2

[*] Running Network Simulation (Transmitting 5 UDP Packets)...
----------------------------------------------------------------------
[Time: 2.000s] [CLIENT SEND]  Packet of 1024 bytes transmitted towards Server.
[Time: 2.020s] [SERVER RECV]  Packet of 1024 bytes received at Server (Echoing back...)
[Time: 3.000s] [CLIENT SEND]  Packet of 1024 bytes transmitted towards Server.
[Time: 3.020s] [SERVER RECV]  Packet of 1024 bytes received at Server (Echoing back...)
...
----------------------------------------------------------------------
[*] SIMULATION RESULTS & SUMMARY:
    - Packets Sent By Client  : 5 Packets (1024 Bytes each)
    - Packets Received At Server: 5 Packets (100% Delivery Rate)
    - Packet Loss             : 0.0% (Zero Packet Loss)
    - Round Trip Time (RTT)   : ~24.1 ms across 2 hops
    - Wireshark PCAPs Created : lab1-network-*.pcap
======================================================================
```

---

## 🛠️ Subsequent Launches: The ns-3 Control Center

Whenever you double-click `INSTALL_ALL_ns3.bat` after installation, it automatically detects your existing environment and presents the **Simulation Control Center**:

```text
==============================================================================
                    ns-3 SIMULATION CONTROL CENTER
                        Created by Qamar Abbas
==============================================================================

  Your ns-3 simulation environment is fully installed and operational!

  Please select an action:
    [1] Launch ns-3 Linux Terminal
    [2] Open ns-3 in Visual Studio Code
    [3] Run Lab 1 Network Simulation (lab1-simulation)
    [4] Run Simple 3-Node Simulation (simple-network)
    [5] Run Smoke Test (hello-simulator)
    [6] Rebuild / Recompile ns-3 Code
    [7] Check Health, Fix Missing Tools & Update Environment
    [8] Re-create Desktop Shortcuts
    [9] Reinstall / Repair Environment from Scratch
    [10] Exit
==============================================================================
```

---

## 🔧 BIOS Virtualization Reference Guide

If the Pre-Flight audit indicates that **Hardware Virtualization** is disabled, follow these steps:

1. Turn off your laptop completely.
2. Turn it back on, and immediately press your manufacturer's BIOS key repeatedly:
   - **HP:** `Esc` or `F10`
   - **Dell:** `F2` or `F12`
   - **Lenovo:** `F2` or `Fn + F2`
   - **Asus:** `F2` or `Del`
   - **Acer:** `F2` or `Del`
3. Navigate to **Advanced**, **Configuration**, or **Security**.
4. Locate **Virtualization Technology**, **Intel VT-x**, or **AMD SVM**.
5. Set it to **[Enabled]**.
6. Press `F10` to Save and Exit. Windows will restart, and you can run `INSTALL_ALL_ns3.bat` again!

---

## 📄 License & Attribution

- **Environment:** [Network Simulator 3 (ns-3)](https://www.nsnam.org/) licensed under GNU GPLv2.
- **Author:** Created by **Qamar Abbas**.
- Intended for educational and laboratory use in academic networking courses.
